<?php 
    session_start();
        $_SESSION['table'] = stripslashes(htmlspecialchars($_POST['name']));
		$_SESSION['id']=array(0);
		$_SESSION['quant']=array(0);
		$_SESSION['name']=array("abc");
		$_SESSION['price']=array(0);
		if($_SESSION['table']=='0')
		{header('Location:admin.php');}
		else{
		header('Location:index.php');}
    
?>