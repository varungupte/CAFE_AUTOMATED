<?php
require('../fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
	// Logo
	$this->Image('var5.png',10,6,30);
	// Arial bold 15
	$this->SetFont('Arial','B',15);
	// Move to the right
	$this->Cell(80);
	// Title
	$this->Cell(30,10,'BILL',1,0,'C');
	// Line break
	$this->Ln(20);
}

// Page footer
function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-15);
	// Arial italic 8
	$this->SetFont('Arial','I',8);
	// Page number
	$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

// Instanciation of inherited class
session_start();
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$max=$_SESSION['count'];
$total=0;
$pro=1;
$pdf->Cell(0,10,'Bill for table number '.$_SESSION['table']." -",0,1);
for($i=1;$i<=$max;$i++){
     $id=$_SESSION['id'][$i];
     $quant=$_SESSION['quant'][$i];
	 $name=$_SESSION['name'][$i];
	 $price=$_SESSION['price'][$i];
	 $pro=$quant*$price;
	 $total+=$pro;
	 $pdf->Cell(0,10,$name." ".$quant." pieces ".$price."\- = ".$pro,0,1);}
	 $pdf->Cell(0,10,"Total amount = ".$total,0,1);
	 $pdf->Cell(0,10,"Thank you sir/ma'am...!!",0,1);
$pdf->Output();
?>
