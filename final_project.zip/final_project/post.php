<?php
session_start();
if(isset($_SESSION['table'])){
    $text=$_POST['text'];
    $fp = fopen("log.html", 'a');
	$fp2= fopen("adminlog.html", 'a');
    fwrite($fp, "<div class='msgln'>(".date("g:i A").") <b>Table no. ".$_SESSION['table']."</b>: ".stripslashes(htmlspecialchars($text))."<br></div>");
   
	fwrite($fp2, "<div class='msgln'>(".date("g:i A").") <b>Table no. ".$_SESSION['table']."</b>: ".stripslashes(htmlspecialchars($text))."<br></div>");
	 fclose($fp); 
    fclose($fp2); 
}

?>