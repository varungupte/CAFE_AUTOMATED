<?php 
session_start();

     
    //Redirect the user
	if(file_exists("log.html") && filesize("log.html") > 0){
	$handle = fopen("log.html", "r");
    
    $contents = fread($handle, filesize("log.html"));
    $unwanted = "Table no. ".$_SESSION['table'];
    $cleanArray= preg_grep("/$unwanted/i",$rows,PREG_GREP_INVERT);
	$handle = fopen("log.html", "w");
	fwrite($fhandle,$cleanarray);
     fclose($handle);}
	 session_destroy();
    header("Location:index.php"); 
?>