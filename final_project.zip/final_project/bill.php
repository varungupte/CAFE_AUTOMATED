<?php 
session_start();
if(isset($_SESSION['table'])){
    $text=$_POST['text'];
    $quant=$_POST['quant'];
	mysql_connect("localhost","root","");
    mysql_select_db("price");
    $query="select price,name from menuprice where id='$text'";
    $con=mysql_query($query);
    $row=mysql_fetch_array($con);
	$price=$row['price'];
	$name=$row['name'];
	session_start();
	array_push($_SESSION['id'],$text);
	array_push($_SESSION['quant'],$quant);
	array_push($_SESSION['name'],$name);
	array_push($_SESSION['price'],$price);
	$_SESSION['count']+=1;
    $fp = fopen("log.html", 'a');
	$fp2= fopen("adminlog.html", 'a');
	$i=$_SESSION['count'];
	
	if($quant>0){
    fwrite($fp, "<div class='msgln'>(".date("g:i A").") <b>Table no. ".$_SESSION['table']."</b>: ".stripslashes(htmlspecialchars($name."  ".$quant." piece "))."<br></div>");
   
	fwrite($fp2, "<div class='msgln'>(".date("g:i A").") <b>Table no. ".$_SESSION['table']."</b>: ".stripslashes(htmlspecialchars($name."  ".$quant." piece "))."<br></div>");
	 }fclose($fp); 
    fclose($fp2); 
}

?>