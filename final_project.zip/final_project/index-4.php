﻿<!DOCTYPE html>
<html lang="en">
<head>
    <title>Menu</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no"/>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/grid.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/contact-form.css">

    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.2.1.js"></script>

    <!--[if lt IE 9]>
    <html class="lt-ie9">
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/..">
            <img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820"
                 alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."/>
        </a> 
    </div>
    <script src="js/html5shiv.js"></script>
    <![endif]-->
 
    <script src='js/device.min.js'></script> 
</head>

<body>
<div class="page">
    <!--========================================================
                              HEADER
    =========================================================-->
    <header>

        <div id="stuck_container" class="stuck_container">
            <div class="container">

                <div class="brand">
                    <h1 class="brand_name">
                        <a href="./">Cafe</a>
                    </h1>
                </div>

                <nav class="nav">
                    <ul class="sf-menu">
                        <li>
                            <a href="./">Home</a>
                        </li>
                        
                        <li>
                            <a href="index-3.php">Menu</a>
							<ul>
                            <li>
                                <a href="appetizers.php">Appetizers</a>
                            </li>
                            <li>
                                <a href="soup.php">Soups</a>
                                
                            </li>
                            <li>
                                <a href="vegetables.php">Vegetables Specialities</a>
                            </li>
							<li>
                                <a href="rice.php">Rice Specialities</a>
                            </li>
							<li>
                                <a href="bread.php">Bread Specialities</a>
                            </li>
							<li>
                                <a href="southindian.php">South Indian Specialities</a>
                            </li>
							<li>
                                <a href="drink.php">Drinks</a>
                            </li>
							<li>
                                <a href="dessert.php">Desserts</a>
                            </li>
                        </ul>
                        </li>
						<li>
                            <a href="index-4.html">Order</a>
                        </li>
						<li>
                            <a href="index-6.php">Reservations</a>
                        </li>
                        <li>
                            <a href="index-4.php">Contacts</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

    </header>
    <!--========================================================
                              CONTENT
    =========================================================-->
    <main>
        <section class="well well__offset-3">
            <div class="container">
                <h2><em>Our</em>Contacts</h2>
                <div class="map">
                  <div id="google-map" class="map_model"></div>
                  <ul class="map_locations">
                    <li data-x="-73.9874068" data-y="40.643180">
                      <p> 9870 St Vincent Place, Glasgow, DC 45 Fr 45. <span>800 2345-6789</span></p>
                    </li>
                  </ul>
                </div>
                <div class="row box-3">
                    <div class="grid_5">
                        <h2>Contacts Form</h2>
                        <form id="contact-form" class='contact-form'>
                            <div class="contact-form-loader"></div>
                            <fieldset>
                                <label class="name">
                                    Your Name:
                                    <input type="text" name="name" placeholder="" value=""
                                           data-constraints="@Required @JustLetters"/>                
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid name.</span>
                                </label>
                
                                <label class="email">
                                    Your E-mail:
                                    <input type="text" name="email" placeholder="" value=""
                                           data-constraints="@Required @Email"/>                
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid email.</span>
                                </label>
                
                                <label class="Subject">
                                    Subject:
                                    <input type="text" name="phone" placeholder="" value=""
                                           data-constraints="@Required"/>                
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*This is not a valid phone.</span>
                                </label>
                
                                <label class="message">
                                    Message:
                                    <textarea name="message" placeholder=""
                                              data-constraints='@Required @Length(min=20,max=999999)'></textarea>                
                                    <span class="empty-message">*This field is required.</span>
                                    <span class="error-message">*The message is too short.</span>
                                </label>
                
                                <div class="btn-wr">
                                    <a class="" href="#" data-type="reset">Clear</a>
                                    <a class="" href="#" data-type="submit">Send</a>
                                </div>
                            </fieldset>
                            <div class="modal fade response-message">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"
                                                    aria-hidden="true">
                                                &times;
                                            </button>
                                            <h4 class="modal-title">Modal title</h4>
                                        </div>
                                        <div class="modal-body">
                                            You message has been sent! We will be in touch soon.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>    
                    <div class="preffix_1 grid_6">
                        <h2>Contacts Information</h2>
                        <h3>If you would like to get in touch with us or need more information, please use the contact form below or give us a call at 9451388867. However, please do understand that this is not a confirmation of any services.

Please note: This form is not for reservations; to make a reservation please fill up the reservation form with all the details.</h3>
                        <address class="address-2">
                            <div class="address_container"><p>EatOye Inc. <br>F-32 Cannaught Place, New Delhi</p></div>
                            <dl>
                                <dt>Telphone:</dt> <dd>+91 9451388867</dd><br>
                                <dt>FAX:</dt> <dd>+91 8127966855</dd><br>
                                <dt>E-mail:</dt> <dd><a href="mailto:varun.gpt1007@gmail.com">varun.gpt1007@gmail.com</a></dd>
                            </dl>                        
                        </address>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!--========================================================
                              FOOTER
    =========================================================-->
    <footer>
        <div class="container">
            <ul class="socials">
                <li><a href="#" class="fa fa-facebook"></a></li>
                <li><a href="#" class="fa fa-tumblr"></a></li>
                <li><a href="#" class="fa fa-google-plus"></a></li>
            </ul>
            <div class="copyright">© <span id="copyright-year"></span> |
                <a href="#">Privacy Policy</a>
            </div>
        </div>
        <div class="text-center ">
                <p> Copyright  &copy;2017  Designed by :<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 hidden-xs hidden-sm main_heading"><img src="images/..png" class="img-responsive" >
    </div></p>                
            </div>
    </footer>
</div>

<script src="js/script.js"></script>
</body>
</html>