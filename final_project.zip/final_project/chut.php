<?php 
session_start();
$session=$_SESSION['answers'];
echo $session;

?>