<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Chat - Customer Module</title>
<link type="text/css" rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="css/bootstrap.css">




<!--priceList window-->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/smoothscroll.js"></script>
<script type="text/javascript" src="js/jquery.parallax.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.js"></script>
<script type="text/javascript" src="js/jquery.nav.js"></script>
<script type="text/javascript" src="js/main.js"></script> 

<meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <link href="css/animate.css" rel="stylesheet">  
      <link href="css/responsive.css" rel="stylesheet">
      
      <link rel="stylesheet" href="ihover-gh-pages/src/ihover.css">   
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css' />
      <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,600,500,700,800,900' rel='stylesheet' type='text/css' />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
      <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>   
      <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
<!--priceList window-->


   

</head><?php
session_start();
 
function loginForm(){
    echo'<div class="container">
                    <div class="jumbotron">
                        <div>
    
    <form action="in.php" method="post" class="form-inline">
        <p>Please enter your table name to continue:</p>
		<div class="form-group">
        <label for="name">Table Name:</label>
        <input type="number" min=0 max=100 name="name" id="name" class="form-control"/>
		</div>
        <input type="submit" name="enter" id="enter" value="Enter" class="btn btn-success" />
		
    </form>';
	 
	 echo "<a style='float:right;' href='index.php' >Back&nbsp;&nbsp;   </a>
	</div></div></div>";
}
 

?>
<?php

    loginForm();

?>



