
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Chat - Customer Module</title>
<link type="text/css" rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="css/bootstrap.css">




<!--priceList window-->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/smoothscroll.js"></script>
<script type="text/javascript" src="js/jquery.parallax.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.js"></script>
<script type="text/javascript" src="js/jquery.nav.js"></script>
<script type="text/javascript" src="js/main.js"></script> 

<meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <link href="css/animate.css" rel="stylesheet">  
      <link href="css/responsive.css" rel="stylesheet">
      
      <link rel="stylesheet" href="ihover-gh-pages/src/ihover.css">   
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css' />
      <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,600,500,700,800,900' rel='stylesheet' type='text/css' />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
      <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>   
      <script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
<!--priceList window-->


   

</head><?php
session_start();

?>

<div class="container">

<div class="jumbotron">
<div class="row">
<div>
    <div>
        <p class="welcome">Welcome , <b>Admin</b></p>
        
        <div style="clear:both"></div>
    </div>   </div> </div>
	<div class="row">
    <div id="chatbox"><?php
if(file_exists("adminlog.html") && filesize("adminlog.html") > 0){
    $handle = fopen("adminlog.html", "r");
    $contents = fread($handle, filesize("adminlog.html"));
    fclose($handle);
     
    echo $contents;
}

?></div></div>
     
		
        
	<p class="logout"><a id="exit" href="logout.php">Exit Chat</a></p>
</div></div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>
<script type="text/javascript">
$("#submitmsg").click(function(){	
		var clientmsg = $("#usermsg").val();
		var tablename=$("#tablemsg").val();
		$.post("post.php", {text: clientmsg,tbname: tablename});				
		$("#usermsg").attr("value", "");
		$("#tablemsg").attr("value", "");
		
		return false;
	});
function loadLog(){		
		var oldscrollHeight = $("#chatbox").attr("scrollHeight") - 20; //Scroll height before the request
		$.ajax({
			url: "adminlog.html",
			cache: false,
			success: function(html){		
				$("#chatbox").html(html); //Insert chat log into the #chatbox div	
				
				//Auto-scroll			
				var newscrollHeight = $("#chatbox").attr("scrollHeight") - 20; //Scroll height after the request
				if(newscrollHeight > oldscrollHeight){
					$("#chatbox").animate({ scrollTop: newscrollHeight }, 'normal'); //Autoscroll to bottom of div
				}				
		  	},
		});
	}
	setInterval (loadLog, 2500);
</script>


